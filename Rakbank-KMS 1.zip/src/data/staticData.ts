export const suggestionsData: { question: string }[] = [
  {
    question: "How to open a gold account in RAKBANK",
  },
  {
    question: "How to raise a dispute for a supplementary credit card",
  },
  {
    question: "How to raise a dispute in RAKFLUX",
  },
  {
    question: "3D Secure on RAKBANK Credit & Debit Cards",
  },
  {
    question: "Liabilities Debit Card Introduction",
  },
  {
    question: "Replace Debit Card",
  },
];
