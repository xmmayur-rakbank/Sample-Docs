export const sourcesLinkData = {
    "Suspect Misuse Third Party Revised Process-2024": {
      redirectLink: "https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1N1c3BlY3QlMjBNaXN1c2UlMjBTY2VuYXJpby9TdXNwZWN0JTIwTWlzdXNlJTIwVGhpcmQlMjBQYXJ0eSUyMFJldmlzZWQlMjBQcm9jZXNzLTIwMjQucGRmP2NzZj0xJndlYj0xJmU9aGI5SEtr&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=QlcySGZGWjFRcFdwRis5T2xwVVVLQ0dTdVZWaC8ybnNacVo3RTVTYWpVYz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY"
    },
    "Contact Center Delegation 2020": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1JldmVyc2FsJTIwUmVxdWVzdCUyMERlbGVnYXRpb25zJTIwTWF0cml4L0NvbnRhY3QlMjBDZW50ZXIlMjBEZWxlZ2F0aW9uJTIwMjAyMC5wZGY_Y3NmPTEmd2ViPTEmZT0wdUdkMTg=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=UnJrOTc3NkliWTBua3hOa05SOWQxaUFoTU9NOW42NkJOT3UwdHZ3dnJLVT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY"
    },
    "List of Services under Digital Banking Business": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL0RpZ2l0YWwlMjBCYW5raW5nJTIwU2VydmljZXMlMjBhbmQlMjBJbnF1aXJpZXMlMjBQYXRoL0xpc3QlMjBvZiUyMFNlcnZpY2VzJTIwdW5kZXIlMjBEaWdpdGFsJTIwQmFua2luZyUyMEJ1c2luZXNzLnBkZj9jc2Y9MSZ3ZWI9MSZlPU95dnRHWA==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=WFh1QVNReU81SUVjUkkvVmZUdnllWWI0UG5tTWRjd3E1akJBT0RJVFFIbz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",
    },
    "Personal Digital Banking services": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL0RpZ2l0YWwlMjBCYW5raW5nJTIwU2VydmljZXMlMjBhbmQlMjBJbnF1aXJpZXMlMjBQYXRoL1BlcnNvbmFsJTIwRGlnaXRhbCUyMEJhbmtpbmclMjBzZXJ2aWNlcy5wZGY_Y3NmPTEmd2ViPTEmZT02bVM1Uk0=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=QlhIYlMrWlhWckg3YlJncTBvWWZrV3N2cnA2R2JSWTZxRnhJZC9KMVIwRT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Digital Pathway App Screen Guides": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL0RpZ2l0YWwlMjBCYW5raW5nJTIwU2VydmljZXMlMjBhbmQlMjBJbnF1aXJpZXMlMjBQYXRoL0RpZ2l0YWwlMjBQYXRod2F5JTIwQXBwJTIwU2NyZWVuJTIwR3VpZGVzLnBkZj9jc2Y9MSZ3ZWI9MSZlPXRJZThyZQ==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=YnMrZFRaR09FTy96MWlBVWJhYisrSDJGT28xWDdGTGJqZktmWG1BcDVOdz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Customer Service SLAs - Cards Accounts PL": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1RBVCUyMFJldHJpZXZhbC9DdXN0b21lciUyMFNlcnZpY2UlMjBTTEFzJTIwLSUyMENhcmRzJTIwQWNjb3VudHMlMjBQTC5wZGY_Y3NmPTEmd2ViPTEmZT1oclZKb04=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=aEE1aVRtaStiYi9HaTRUNUFJcHZhWmJkMHZZdzRST0tQUHV5V1F5NUYzRT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Existing Customer-SAMSUNG TnCs": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvRXhpc3RpbmclMjBDdXN0b21lci1TQU1TVU5HJTIwVG5Dcy5wZGY_Y3NmPTEmd2ViPTEmZT1aYlhvMDI=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=S1Y2M3B0SkR0a01DbHhqTTEyWXBuMzVMQkVpcTloYTdyejZxalZIdWxkcz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Existing Customer-SAMSUNG FAQs": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvRXhpc3RpbmclMjBDdXN0b21lci1TQU1TVU5HJTIwRkFRcy5wZGY_Y3NmPTEmd2ViPTEmZT1BMUFjRWo=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=UmtrZ2R6bXREVkRLdlRJMTZSZUhmNUs5ODVKTXJJUmdENm5aaVh4dW1wcz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Travel Offer-Nov24 to Dec24 TnCs": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvVHJhdmVsJTIwT2ZmZXItTm92MjQlMjB0byUyMERlYzI0JTIwVG5Dcy5wZGY_Y3NmPTEmd2ViPTEmZT1QaEk4UHk=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=ZHpBa3NhSzlQdXN5ekdIcjNvTEFHcUcxTHF5eVZBSm96MWV4MFNpREZjbz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Samsung ATL Campaign (01Nov24 - 31Dec24) TnCs": {
        redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvU2Ftc3VuZyUyMEFUTCUyMENhbXBhaWduJTIwKDAxTm92MjQlMjAtJTIwMzFEZWMyNCklMjBUbkNzLnBkZj9jc2Y9MSZ3ZWI9MSZlPVRubzdLTg==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=U2Q5ekJYK3ZLNFZKMUQ4WGlpUUY5ek4rdmU2VjZhYmo5THEyQ1RBUkIraz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Samsung ATL Campaign (01Nov24 - 31Dec24) FAQs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvU2Ftc3VuZyUyMEFUTCUyMENhbXBhaWduJTIwKDAxTm92MjQlMjAtJTIwMzFEZWMyNCklMjBGQVFzLnBkZj9jc2Y9MSZ3ZWI9MSZlPWdtajFpNw==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=ekJVOFZmTnRIN1pMdjRPWVJMRjRLVm8rVTVDMXk4WFN4WWJqTFNXSFRWND0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "SAMSUNG BTL Campaign-TnCs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvU2Ftc3VuZyUyMEJUTCUyMENhbXBhaWduLUZBUXMucGRmP2NzZj0xJndlYj0xJmU9STdyREFF&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=QnRrV0E2cUJYaC9ZQ1hFMG0yNUVUY0t5ek5jYXRwRVZaT3VJVWprd1hMaz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Samsung BTL Campaign-FAQs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvU2Ftc3VuZyUyMEJUTCUyMENhbXBhaWduLUZBUXMucGRmP2NzZj0xJndlYj0xJmU9STdyREFF&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=QnRrV0E2cUJYaC9ZQ1hFMG0yNUVUY0t5ek5jYXRwRVZaT3VJVWprd1hMaz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "NTB CASA TCs_Sept24": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvTlRCJTIwQ0FTQSUyMFRDc19TZXB0MjQucGRmP2NzZj0xJndlYj0xJmU9a0tHUkhk&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=OEp0R1IydzhPN3h1MEp3U2dxMjVzSWVqZ0JVbEFFUkZJZzBGbnFrT2tiZz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Early Engagement Program FAQs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvRWFybHklMjBFbmdhZ2VtZW50JTIwUHJvZ3JhbSUyMEZBUXMucGRmP2NzZj0xJndlYj0xJmU9OFlla2ll&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=dG9TZVZEaUFzVGVjckhCZ281ZlR1bWFjTnZsTTY2bXhlMzFpVVljYUlGaz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "BonusRetention+FAQs-2024": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvQm9udXNSZXRlbnRpb24rRkFRcy0yMDI0LnBkZj9jc2Y9MSZ3ZWI9MSZlPWVkN3ZHYQ==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=YkNxQzBQR0hEOFRSV05aekZjMG9EUGZKYnhtVEVlZEFMT2VSMkhmanNLRT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "FAQs – China Campaign": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvRkFRcyUyMCVFMiU4MCU5MyUyMENoaW5hJTIwQ2FtcGFpZ24ucGRmP2NzZj0xJndlYj0xJmU9VTVoQlk4&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=RDVUQURidURZU09uWjhlNDZaaW0ra2dpOFdZOFNEdzZKTmNNUnk1UlEwWT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "FAQs – Zero Fee Campaign to the UK": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvRkFRcyUyMCVFMiU4MCU5MyUyMFplcm8lMjBGZWUlMjBDYW1wYWlnbiUyMHRvJTIwdGhlJTIwVUsucGRmP2NzZj0xJndlYj0xJmU9dGdSVHVn&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=OE9HRlV4OS96aHRnV2VidDBaMnM5Y2JoU0p4bU1KeEErNnJSczNwYzFFMD0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Salary Transfer Promotion Dec24 to Q1-25": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvU2FsYXJ5JTIwVHJhbnNmZXIlMjBQcm9tb3Rpb24lMjBEZWMyNCUyMHRvJTIwUTEtMjUucGRmP2NzZj0xJndlYj0xJmU9VU51b0RP&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=QzZzTCtNaldWOEIrL2JqblZoT0sySkJjUWVHeldBd1VXSlk3ZzhGQjQ4Yz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "TC- Egypt_v06": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMvVEMtJTIwRWd5cHRfdjA2LnBkZj9jc2Y9MSZ3ZWI9MSZlPVZzUUNiVA==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=cUh1SVFVZFhxdTNlckN4bFRUREV6QjBqM0MwaHdrb2dOQjZVZDcxRVdaVT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "DOB FAQs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvRE9CJTIwRkFRcy5wZGY_Y3NmPTEmd2ViPTEmZT1ES3RGZHY=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=ajh2YnhHeHdkVUpjdGx0cTA0WjdpbDBDcEwxUUNWNWt6ZjYyVWNqaTBDRT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "June-July24 Travel Offer TnC": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvSnVuZS1KdWx5MjQlMjBUcmF2ZWwlMjBPZmZlciUyMFRuQy5wZGY_Y3NmPTEmd2ViPTEmZT1hVWp4dlk=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=alAxT3pkOVArMVlWYkg3eWFsbzBPaWZONS9BRE1KWUQ4SmhvVjVVOXpyUT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "RAKBANK x SAMSUNG Campaign TnCs": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvUkFLQkFOSyUyMHglMjBTQU1TVU5HJTIwQ2FtcGFpZ24lMjBUbkNzLnBkZj9jc2Y9MSZ3ZWI9MSZlPVNiWnJ5eA==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=SXlwR2poRDJtUEpIS0xWVWkxUTJXQld3ck9zTDRLR1AvQ1BnVTFCc09Hdz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "FAQs – Lea Salonga Campaign": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvRkFRcyUyMCVFMiU4MCU5MyUyMExlYSUyMFNhbG9uZ2ElMjBDYW1wYWlnbi5wZGY_Y3NmPTEmd2ViPTEmZT1rWGVMWnk=&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=VE14TkpYVjd6QjZyT0JUMkVaM1lGOTBmR1FhVnNJZHdmLzA2MXExN0E5ST0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Samsung FAQs ATL": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvU2Ftc3VuZyUyMEZBUXMlMjBBVEwucGRmP2NzZj0xJndlYj0xJmU9NjZlcUFj&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=WWJGKzYzWDJkZEJHL1g4RmU2L2V2REF2TmhlOUwweUpITHoxRGNXVSs2dz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "SME Credit Card Campaign_v2": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvU01FJTIwQ3JlZGl0JTIwQ2FyZCUyMENhbXBhaWduX3YyLnBkZj9jc2Y9MSZ3ZWI9MSZlPXBpNVhGeQ==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=VXNONy9ZUzZKRE5QNjl4QWVSakREb1BWYXhaSTFMSU5OeFJOQ2owSXAyWT0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "SME Debit Card Campaign_v2": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvU01FJTIwRGViaXQlMjBDYXJkJTIwQ2FtcGFpZ25fdjIucGRmP2NzZj0xJndlYj0xJmU9eWNYOGxN&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=RzFUYm4wZ1E5ZDN1bW5sZGdGaUR4dTBLZll3Z1NSYjhjUE1wMmdEanUzMD0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "T&C- Philippines RMT CCA-v03": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvVCUyNkMtJTIwUGhpbGlwcGluZXMlMjBSTVQlMjBDQ0EtdjAzLnBkZj9jc2Y9MSZ3ZWI9MSZlPVNNaHl0YQ==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=T2RwWWRrdXFjb3dqSGhKRlBtVC9yb01xVnpQTHJHVVhURk5HYk1kQmNxMD0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    },
    "Terms Conditions Joining Bonus": {
                redirectLink:"https://us-west-2.protection.sophos.com/?d=sharepoint.com&u=aHR0cHM6Ly9yYWtiYW5rLnNoYXJlcG9pbnQuY29tLzpiOi9yL3NpdGVzL2tub3dsZWRnZW1nbXR0ZXN0aW5nL1NoYXJlZCUyMERvY3VtZW50cy9LTVMlMjBUZXN0aW5nJTIwUGhhc2UlMjAxL1Byb21vdGlvbnMlMjAoZXhwaXJlZCkvVGVybXMlMjBDb25kaXRpb25zJTIwSm9pbmluZyUyMEJvbnVzLnBkZj9jc2Y9MSZ3ZWI9MSZlPVVnQUlQRA==&p=m&i=NjQ4NmYyNmU2MTY5NDAxNTYyOTRlOWI1&t=dU5ZREFqNDRucjRWUkU2NDF2TUsvQTd5N1VCMysya3p6UmUzZ0hlYjBqcz0=&h=0b02de50558347bdaf3c711de3f4ef89&s=AVNPUEhUT0NFTkNSWVBUSVbb87KgfbYvKUDQX-YP_wf2G3OTEyy6pZcadqFPG36h7oi_-aBtdZelVoFZSpWXgcY",

    }
  };
  