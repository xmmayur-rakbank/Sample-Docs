import React, { useState, useEffect, useRef } from 'react';
import './conversation.scss';
import { useSelector } from 'react-redux';
import Searchbar from '../../components/searchbar/coversation-searchbar/Searchbar';
import SkeletonLoader from '../../utils/loader/skeleton/Skeleton';
import Answer from '../../components/conversation/answer/Answer';
import Question from '../../components/conversation/question/Question';

interface ContextEntry {
  search_type?: string;
  model?: string;
  chunk_content?: string;
  score?: number;
  filename?: string;
  file_location?: string;
  chunk_heading?: string;
}

interface BaseMessage {
  id: number;
  value: string;
  messageId: string;
}

interface AnswerMessage extends BaseMessage {
  type: 'answer';
  context: ContextEntry[]; // context is required for 'answer'
}

interface QuestionMessage extends BaseMessage {
  type: 'question';
  // context is not allowed for 'question'
}

type Message = AnswerMessage | QuestionMessage;

interface RootState {
  stateReducers: {
    messages: Message[];
  };
}

const Conversation: React.FC = () => {
  const messages = useSelector((state: RootState) => state.stateReducers.messages);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null); // Create a reference


  // Scroll to the bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);


  return (
    <div className='rakbank-conversation-page'>
      <div className="conversation-container">

        {messages.map((msg, index) => (
          msg.type === 'answer' ? <Answer key={msg.id} index={index} totalMessagesLength={messages?.length} msg={msg} setIsLoading={setIsLoading}/> :
            msg.type === 'question' ? <Question key={msg.id} msg={msg} /> : null
        ))}

        {isLoading && <SkeletonLoader />}

        {/* This is the invisible element used for scrolling to the bottom */}
        <div ref={messagesEndRef} />
      </div>
      <div className="searchbarClass">
        <Searchbar isLoading={isLoading} setIsLoading={setIsLoading} />
      </div>
    </div>
  );
};

export default Conversation;
