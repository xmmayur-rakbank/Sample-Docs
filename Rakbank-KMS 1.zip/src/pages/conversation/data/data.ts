export const relatedSearchSuggestions: { title: string; newTitle: string }[] = [
    {
        title: "What documents are needed to open a gold account in RAKBANK",
        newTitle: "How to open a gold account in RAKBANK",
    },
    {
        title: "Are there any fees associated with opening a gold account in RAKBANK",
        newTitle: "Gold account fees in RAKBANK",
    },
    {
        title: "Can I open a gold account in RAKBANK online or do I need to visit a branch",
        newTitle: "Online opening of gold account in RAKBANK",
    },
    {
        title: "How does the interest rate on a gold account in RAKBANK compare to other banks",
        newTitle: "RAKBANK gold account interest rate comparison",
    },
];

interface RelatedSearchItem {
    id: number;
    iconText: string;
    title: string;
    meta: string;
    procedure: string;
    description: string;
}

export const relatedSearchData: RelatedSearchItem[] = [
    {
        id: 1,
        iconText: "PDF",
        title: "Liabilities Credit Card Introduction",
        meta: "Updated on July 24, 2024 • Author •",
        procedure: "Ready Reckoners",
        description: "Lorem ipsum dolor sit amet, credit card block guide. Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae...",
    },
    {
        id: 2,
        iconText: "WEB",
        title: "Credit and Debit Card PIN Solution FAQS",
        meta: "Updated on Apr 26, 2024 • Author •",
        procedure: "Operating Procedures",
        description: "Lorem ipsum dolor sit amet, credit card block guide. Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae...",
    },
    {
        id: 3,
        iconText: "DOCX",
        title: "Replace Credit Card",
        meta: "Updated on Aug 2, 2023 • Author • ",
        procedure: "Operating Procedures",
        description: "Lorem ipsum dolor sit amet, credit card block guide. Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae...",
    },
    {
        id: 4,
        iconText: "WEB",
        title: "Credit and Debit Card PIN Solution FAQS",
        meta: "Updated on Apr 26, 2024 • Author •",
        procedure: "Operating Procedures",
        description: "Lorem ipsum dolor sit amet, credit card block guide. Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae...",
    },
    {
        id: 5,
        iconText: "PDF",
        title: "Liabilities Credit Card Introduction",
        meta: "Updated on July 24, 2024 • Author •",
        procedure: "Ready Reckoners",
        description: "Lorem ipsum dolor sit amet, credit card block guide. Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae...",
    },
];


export const footerLinkData: { path: string; title: string }[] = [
    { path: './link', title: 'Products' },
    { path: './link', title: 'Download' },
    { path: './link', title: 'Pricing' },
    { path: './link', title: 'Locations' },
    { path: './link', title: 'Server' },
    { path: './link', title: 'Countries' },
    { path: './link', title: 'Blog' },
    { path: './link', title: 'Engage' },
    { path: './link', title: 'RakBank ?' },
    { path: './link', title: 'FAQ' },
    { path: './link', title: 'Tutorials' },
    { path: './link', title: 'About Us' },
    { path: './link', title: 'Privacy Policy' },
    { path: './link', title: 'Terms of Services' },
];


interface SourceDataItem {
    type: string;
    title: string;
}

export const sourcesData: SourceDataItem[] = [
    {
        type: "WEB",
        title: "Gold Account S&P Guide"
    },
    {
        type: "WEB",
        title: "Card Activation and PIN retrieval"
    },
    {
        type: "ASPX",
        title: "Liabilities Debit Card Introduction Guide"
    },
    {
        type: "ASPX",
        title: "Liabilities Debit Card Introduction Guide"
    },
    {
        type: "WEB",
        title: "Card Activation and PIN retrieval"
    },
];
