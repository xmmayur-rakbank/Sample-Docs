// Define the types for the data structure
interface LinkData {
    linkData: string[];
}

interface PdfData {
    type: string;
    title: string;
}

interface BoxData {
    title: string;
    description: string;
    image: string;
}

interface  FollowQuestionData{
    title: string;
    description: string;
    image: string;
}

interface Data {
    linkData: string[];
    pdfData: PdfData[];
    boxData: BoxData[];
    followQuestionData: FollowQuestionData[];
}



// Export the data with the defined types
export const data: Data = {
    linkData: [
        "How to open a gold account in RAKBANK",
        "How to raise a dispute for a supplementary credit card",
        "How to raise a dispute in RAKFLUX",
        "3D Secure on RAKBANK Credit & Debit Cards",
        "Liabilities Debit Card Introduction",
        "Replace Debit Card"
    ],
    pdfData: [
        { type: "WEB", title: "Liabilities Debit Card Introduction" },
        { type: "ASPX", title: "Liabilities Debit Card Introduction" },
        { type: "WEB", title: "Card Activation and PIN retrieval" },
        { type: "PDF", title: "Replace Debit Card" },
    ],
    boxData: [
        { image: require('../../../assets/icon/card.png'), title: "" , description: "When can a customer close a credit card and transfer balance" },
        { image: require('../../../assets/icon/arrow.png'), title: "" , description: "Customer request for credit limit increase before card closure" },
        { image: require('../../../assets/icon/dollar.png'), title: "" , description: "How to request a refund on remaining card balance after closure" },
    ],

    followQuestionData:[
        { image: require('../../../assets/icon/dollar.png'), title: "" , description: "Do you need assistance with logging into your personal digital banking account?" },  
        { image: require('../../../assets/icon/card.png'), title: "" , description: "Are you looking for information on how to contact Rakbank customer service?" },
        { image: require('../../../assets/icon/arrow.png'), title: "" , description: "Do you need help with any other credit card-related services?" },
    ]
};
