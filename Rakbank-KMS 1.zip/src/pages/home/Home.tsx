import React from 'react';
import './home.scss';
import HomeSearchbar from '../../components/searchbar/home-searchbar/HomeSearchbar';
import { data } from './data/staticData';
import useSuggestionBoxClickHandler from '../../utils/custom-hooks/useSuggestionBoxClickHandler';
const Home: React.FC = () => {
  const suggestionBoxClickHandler=useSuggestionBoxClickHandler();
  return (
    <div className="insights-container">
      <header className="insights-header">
        <span>Hello 👋</span>
        <p>
          Welcome! KMS (Knowledge Management System) tool helps you retrieve insights on everything quickly.
          Type your question below to get started.
        </p> 
      </header>
      <div className="home-page-suggestion-container">
        {data.boxData.map((box: { image: string; title: string; description: string }, index: number) => (
          <button className="home-suggestion-box" key={index} onClick={()=>suggestionBoxClickHandler(box.description,true)}>
            <div className="top"><img style={{ height: "24px" }} src={box.image} alt={box.title} /></div>
            <div className="middle">{box.title}</div>
            <div className="bottom">{box.description}</div>
          </button>
        ))}
      </div>
      <div className="homeSearchContainer">
        <HomeSearchbar /> 
      </div>
    </div>
  );
}

export default Home;