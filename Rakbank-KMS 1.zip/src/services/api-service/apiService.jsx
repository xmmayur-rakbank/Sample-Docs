import axios from 'axios';

// Initialize Axios instance
const apiClient = axios.create({
  baseURL : `${window.location.origin}${window.location.pathname.split("/").splice(0, 5).join("/")}`,
  timeout: 60000, // 60 seconds timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request Interceptor (e.g., for adding auth tokens)
apiClient.interceptors.request.use(
  (config) => {
    // Add authentication token, if available
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor (e.g., for error handling)
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle unauthorized errors, token refresh, etc.
    if (error.response?.status === 401) {
      // Handle token refresh or redirect to login
    }
    return Promise.reject(error);
  }
);

// Define API methods
const apiService = {
  // Generic GET method
  get: (url, params) => apiClient.get(url, { params }),

  // Generic POST method
  post: (url, data) => apiClient.post(url, data),

  // Generic PUT method
  put: (url, data) => apiClient.put(url, data),

  // Generic DELETE method
  delete: (url) => apiClient.delete(url),

  // Custom API methods
  fetchChatAnswer: (data) => apiClient.post(`/rag`, data),
  sendChat: (data) => 
    apiClient.post('/chat', data, {
      params: {
        username: 'Mayur',
        is_followup: false,
      },
    }),
    postFeedback:(data)=>apiClient.post('/feedback',data)
};

export default apiService;
