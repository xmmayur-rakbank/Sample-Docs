import { combineReducers } from "redux";
import stateReducers from "./reducer";

const reducers = combineReducers({
    stateReducers: stateReducers,
})

export default reducers;