const initialState = {
    messages: []
};

const stateReducers = (state = initialState, action) => {
    switch (action.type) {
        case 'UPDATE_MESSAGES':
            return { ...state, messages: [...state.messages, action.payload] };
        case 'START_NEW_CONVERSATION':
            return initialState;
        default:
            return state;
    }
};

export default stateReducers;