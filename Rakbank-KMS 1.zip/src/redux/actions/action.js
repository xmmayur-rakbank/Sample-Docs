export const updateMessages = (message) => ({
    type: "UPDATE_MESSAGES",
    payload: message,
})

export const startNewConversation = (message) => ({
    type: "START_NEW_CONVERSATION",
    payload: message,
})