import './App.css';
import Layout from './layout/Layout';
import { Route, Routes } from 'react-router-dom';
import Home from './pages/home/Home';
import Conversation from './pages/conversation/Conversation';
import PageNotFound from './utils/404-page/PageNotFound';

const App: React.FC = () => {
  return (
    <div className='App'>
      <Routes>
        <Route path="/" element={<Layout Cmp={Home} />} />
        <Route path="/conversation" element={<Layout Cmp={Conversation} />} />
        <Route path='*' element={<PageNotFound />} />
      </Routes>
    </div>
  );
}

export default App;