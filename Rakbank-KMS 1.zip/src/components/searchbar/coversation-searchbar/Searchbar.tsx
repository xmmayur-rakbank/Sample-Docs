import "./searchbar.scss";
import { useState, useEffect, useRef } from "react";
import { ReactComponent as CrossIcon } from "../../../assets/icon/cross.svg";
import { ReactComponent as ArrowForwardIcon } from "../../../assets/icon/arrow-forward.svg";
import apiService from "../../../services/api-service/apiService";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { updateMessages } from "../../../redux/actions/action";
import { v4 as uuidv4 } from "uuid";

interface SearchbarProps {
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

export default function Searchbar({ isLoading, setIsLoading }: SearchbarProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const question = useSelector((state: any) => state.stateReducers.query);
  const answer = useSelector((state: any) => state.stateReducers.answer);
  const messages = useSelector((state: any) => state.stateReducers.messages);
  const [searchTerm, setSearchTerm] = useState<string>(question);
  const [searchFieldFocus, setSearchFieldFocus] = useState<boolean>(false);
  const [conversationId, setConversationId] = useState<string>(uuidv4());
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const isInitialMount = useRef(true);

  interface AnswerMessageItem {
    id: string;
    messageId: string;
    value: string;
    type: string;
    isLoading: boolean;
    context: any[]
  }

  interface QuestionMessageItem {
    id: string;
    messageId: string;
    value: string;
    type: string;
    isLoading: boolean;
  }

  useEffect(() => {
    if (isInitialMount.current) {
      console.log("messages in useEffect", messages);
      if (messages[0]?.value) {
        fetchAnswer(messages[0].value, "useEffect");
        inputRef.current?.focus();
      } else {
        navigate("/");
      }
      isInitialMount.current = false;
    }
  }, []);

  const fetchAnswer = async (question: string, type: string) => {
    console.log("call", type);
    setSearchTerm("");
    try {
      setIsLoading(true);
      const payload = {
        departmant: ["Sales"],
        chatRequest: {
          Query: question,
          ChatHistory: [
            {
              user: "",
              assistant: "",
              conversationId: conversationId,
              messageId: Date.now().toString(),
            },
          ],
        },
      };

      const response = await apiService.sendChat(payload);
      console.log("response", response);
      const newMessage: AnswerMessageItem = {
        id: conversationId,
        value: response.data.answer.content,
        messageId: Date.now().toString(),
        type: "answer",
        isLoading: true,
        context: response.data.context || []
      };
      dispatch(updateMessages(newMessage));
    } catch (error) {
      console.log(error);
      const newMessage: AnswerMessageItem = {
        id: conversationId,
        value: "Unable to get response!",
        messageId: Date.now().toString(),
        type: "answer",
        isLoading: true,
        context: []
      };
      setTimeout(() => {
        dispatch(updateMessages(newMessage));
      }, 2000);
    } finally {
      setTimeout(() => {
        setIsLoading(false);
      }, 2000);
    }
  };

  const onChangeHandeler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const arrowClickHandeler = (question: string) => {
    console.log("arrowClickHandeler", question);
    if (question && !isLoading) {
      const newMessage: QuestionMessageItem = {
        id: conversationId,
        messageId: Date.now().toString(),
        value: question,
        type: "question",
        isLoading: true,
      };
      dispatch(updateMessages(newMessage));
      setSearchTerm("");
      fetchAnswer(question, "arrowClickHandeler");
    }
  };

  const handleEnterInInputField = (e: React.KeyboardEvent<HTMLInputElement>, question: string) => {
    if (e.key === "Enter" && !isLoading && question) {
      const newMessage: QuestionMessageItem = {
        id: conversationId,
        messageId: Date.now().toString(),
        value: question,
        type: "question",
        isLoading: true,
      };
      dispatch(updateMessages(newMessage));
      fetchAnswer(question, "handleEnterInInputField");
    }
  };

  const crossClickHandeler = () => {
    setSearchTerm(""); // reset searchTerm
  };

  return (
    <div
      className={`rakbank-searchbar-component ${searchFieldFocus ? "rakbank-searchbar-active" : ""}`}
    >
      <div className="searchIcon">
        {/* <SearchIcon /> */}
      </div>
      <input
        type="text"
        placeholder={answer ? "Ask follow-up question" : "Ask Anything"}
        className="search-input-field"
        onFocus={() => setSearchFieldFocus(true)}
        onBlur={() => setSearchFieldFocus(false)}
        onKeyUp={(e) => handleEnterInInputField(e, searchTerm)}
        onChange={onChangeHandeler}
        value={searchTerm}
        ref={inputRef}
      />
      {searchFieldFocus || searchTerm ? (
        <>
          <span>
            <CrossIcon
              style={{ cursor: "pointer", color: "rgba(102, 102, 102, 1)" }}
              onClick={crossClickHandeler}
            />
          </span>
          <span className="arrow-forward">
            <ArrowForwardIcon onClick={() => arrowClickHandeler(searchTerm)} />
          </span>
        </>
      ) : null}
    </div>
  );
}
