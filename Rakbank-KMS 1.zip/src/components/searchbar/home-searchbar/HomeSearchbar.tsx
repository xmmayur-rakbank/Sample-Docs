import "./homeSearchbar.scss";
import { useState, ChangeEvent, KeyboardEvent } from "react";
import { ReactComponent as CrossIcon } from "../../../assets/icon/cross.svg";
import { ReactComponent as ArrowForwardIcon } from "../../../assets/icon/arrow-forward2.svg";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { updateMessages } from "../../../redux/actions/action";

interface MessageItem {
  id: number;
  value: string;
  type: string;
  isLoading: boolean;
}
 
export default function HomeSearchbar() {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [searchFieldFocus, setSearchFieldFocus] = useState<boolean>(false);
  const [lastSearchTerm, setLastSearchTerm] = useState<string>(""); // State to track last search term
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const onChangeHandler = (e: ChangeEvent<HTMLInputElement>) => {
    console.log("onChangeHandler", e.target.value);
    setSearchTerm(e.target.value);
  };

  const arrowClickHandler = (question: string) => {
    console.log("arrowClickHandler", question);
    if (question && question !== lastSearchTerm) {  // Avoid dispatching the same query
      const newMessage: MessageItem = {
        id: Date.now(), // Unique ID based on timestamp
        value: question,
        type: 'question',
        isLoading: true,
      };
      dispatch(updateMessages(newMessage));
      navigate('/conversation');
      setSearchTerm("");
      setLastSearchTerm(question); // Track last search term
    }
  };

  const handleEnterInInputField = (e: KeyboardEvent<HTMLInputElement>, question: string) => {
    if (e.key === "Enter" && question && question !== lastSearchTerm) {  // Avoid dispatching the same query
      const newMessage: MessageItem = {
        id: Date.now(), // Unique ID based on timestamp
        value: question,
        type: 'question',
        isLoading: true,
      };
      dispatch(updateMessages(newMessage));
      navigate('/conversation');
      setSearchTerm("");
      setLastSearchTerm(question); // Track last search term
    }
  };

  const crossClickHandler = () => {
    setSearchTerm(""); // reset searchTerm
    setLastSearchTerm(""); // reset lastSearchTerm
  };

  return (
    <div
      className={`rakbank-home2-searchbar-component ${
        searchFieldFocus ? "rakbank-searchbar-active" : ""
      }`}
    >
      <input
        type="text"
        placeholder="Ask or search for anything"
        className="search-input-field"
        onFocus={() => setSearchFieldFocus(true)}
        onBlur={() => setTimeout(() => setSearchFieldFocus(false), 200)} // Prevent closing dropdown before click event is registered
        onKeyUp={(e) => handleEnterInInputField(e, searchTerm)}
        onChange={onChangeHandler}
        value={searchTerm}
      />
      {(searchFieldFocus || searchTerm) && (
        <>
          <span className="cross-icon">
            <CrossIcon
              style={{ cursor: "pointer", color: "rgba(102, 102, 102, 1)" }}
              onClick={crossClickHandler}
            />
          </span>
          <span className="arrow-forward">
            <ArrowForwardIcon onClick={() => arrowClickHandler(searchTerm)} />
          </span>
        </>
      )}
    </div>
  );
}
