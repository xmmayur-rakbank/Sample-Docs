import './footer.scss';
import { footerLinkData } from '../../../pages/conversation/data/data';
import { Link } from 'react-router-dom';

interface FooterLink {
    title: string;
    path: string;
}

export default function Footer() {
    const midpoint = Math.ceil(footerLinkData.length / 2);
    const column1Links: FooterLink[] = footerLinkData.slice(0, midpoint);
    const column2Links: FooterLink[] = footerLinkData.slice(midpoint);

    return (
        <div className="conversation-page-footer-component">
            <div className="leftFooter">
                <span className="footer-logo">rakbank</span>
                <div className="textareaStyling">
                    <span className="footer-help-title">Need Help?</span>
                    <span className="footer-help-text">
                        Submit your message and we can contact you
                    </span>
                    <textarea
                        placeholder="Type Your message"
                        className="textAreaElement"
                    />
                    <button id="footerSubmitButton">Submit</button>
                </div>
            </div>
            <div className="rightFooter">
                <div className="footer__column">
                    {column1Links.map((link: FooterLink, index: number) => (
                        <Link className="footer__link" to={link.path} key={index}>
                            {link.title}
                        </Link>
                    ))}
                </div>
                <div className="footer__column">
                    {column2Links.map((link: FooterLink, index: number) => (
                        <Link className="footer__link" to={link.path} key={index + midpoint}>
                            {link.title}
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    );
}