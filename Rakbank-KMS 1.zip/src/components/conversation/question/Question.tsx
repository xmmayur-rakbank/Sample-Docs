import React from 'react';
import './question.scss';

interface QuestionProps {
  msg: {
    id: number;
    type: 'answer' | 'question';
    value: string; // Changed from content to value
  };
}

const Question: React.FC<QuestionProps> = ({ msg }) => {
  return (
    <div className='message-bubble-container'>
      <div className="message-bubble">{msg.value}</div> {/* Changed to msg.value */}
    </div>
  );
};


export default Question;


