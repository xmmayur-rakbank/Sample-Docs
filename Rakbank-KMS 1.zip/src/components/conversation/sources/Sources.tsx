import React, { useState, useEffect, useRef } from 'react';
import './source.scss';
import { ReactComponent as MenubarIcon } from '../../../assets/icon/menubar.svg';
import { sourcesData } from '../../../pages/conversation/data/data';

type SourceItem = {
    type: string;
    title: string;
};

export default function Sources() {
    const [showLeftButton, setShowLeftButton] = useState(false);
    const [showRightButton, setShowRightButton] = useState(true);
    const scrollRef = useRef<HTMLDivElement | null>(null);

    const scroll = (direction: number) => {
        if (scrollRef.current) {
            scrollRef.current.scrollBy({
                left: direction * 200,
                behavior: 'smooth',
            });
        }
    };

    const handleScroll = () => {
        const container = scrollRef.current;
        if (container) {
            const maxScrollLeft = container.scrollWidth - container.clientWidth - 5;
            setShowLeftButton(container.scrollLeft > 0);
            setShowRightButton(container.scrollLeft < maxScrollLeft);
        }
    };

    useEffect(() => {
        const container = scrollRef.current;
        container?.addEventListener('scroll', handleScroll);
        handleScroll(); // Initial check
        return () => container?.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="sourceCardContainer">
            <div className="sourcesTitle">
                <MenubarIcon />
                <span className="sources-text">Sources <span className="sources-number">({sourcesData.length})</span></span>
            </div>

            <div className="sliderContainer">
                {showLeftButton && (
                    <span className="sliderAvatar" onClick={() => scroll(-1)}>
                        &#8249;
                    </span>
                )}
                <div className="cardsContainer" ref={scrollRef}>
                    {sourcesData.map((item: SourceItem, index: number) => (
                        <div className="slider-card" key={index}>
                            <span className="cardIconStyle">{item.type}</span>
                            <span className="cardDetail">{item.title}</span>
                        </div>
                    ))}
                </div>
                {showRightButton && (
                    <span
                        className="sliderAvatar"
                        onClick={() => scroll(1)}
                    >
                        &#8250;
                    </span>
                )}
            </div>
        </div>
    );
}
