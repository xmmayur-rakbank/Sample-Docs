import React, { useState } from 'react';
import './relatedSearch.scss';
import { ReactComponent as SmartSearchIcon } from '../assets/icon/smart-search.svg';
import { ReactComponent as ArrowForwardIcon } from '../../../assets/icon/arrow-forward.svg';

interface RelatedSearchProps {
    title: string;
}

const RelatedSearch: React.FC<RelatedSearchProps> = ({ title }) => {
    const [isOpen, setIsOpen] = useState<boolean>(false);

    return (
        <div className="searchCard">
            <div className="header-smart-search">
                {isOpen && <span id="smartSearch"><SmartSearchIcon /> Smart Search</span>}
                <div className="headerToggle" onClick={() => setIsOpen(!isOpen)}>
                    <span id="titleText">{title}</span>
                    {/* Toggle Arrow Button */}
                    <div><ArrowForwardIcon className="toggleArrow" /></div>
                </div>
            </div>
        </div>
    );
};

export default RelatedSearch;