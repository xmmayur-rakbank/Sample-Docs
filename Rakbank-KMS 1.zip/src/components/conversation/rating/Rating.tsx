import React, { useState } from 'react';
import './rating.scss';

interface RatingData {
  value: number;
  tooltipText: string;
}

interface RatingProps {
  openModal: (rating: RatingData) => void;
}

const Rating: React.FC<RatingProps> = ({ openModal }) => {
  const [selectedRating, setSelectedRating] = useState<RatingData | null>(null);
  const [hoveredRating, setHoveredRating] = useState<number | null>(null);

  const handleClick = (rating: RatingData) => {
    setSelectedRating(rating);
    openModal(rating);
  };

  const handleMouseEnter = (ratingValue: number) => {
    setHoveredRating(ratingValue);
  };

  const handleMouseLeave = () => {
    setHoveredRating(null);
  };

  const ratingData: RatingData[] = [
    {
      value: 1,
      tooltipText: "Incomplete or irrelevant information",
    },
    {
      value: 2,
      tooltipText: "Lacks important details",
    },
    {
      value: 3,
      tooltipText: "Some useful information provided",
    },
    {
      value: 4,
      tooltipText: "Mostly complete and relevant",
    },
    {
      value: 5,
      tooltipText: "Comprehensive and fully relevant",
    },
  ];

  return (
    <div className="rating-scale">
      {ratingData.map((rating) => (
        <div
          key={rating.value}
          className={`rating-item ${selectedRating?.value === rating.value ? 'selected' : ''}`}
          onClick={() => handleClick(rating)}
          onMouseEnter={() => handleMouseEnter(rating.value)}
          onMouseLeave={handleMouseLeave}
        >
          {rating.value}
          {hoveredRating === rating.value && (
            <div className="tooltip">
              {rating.tooltipText}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Rating;
