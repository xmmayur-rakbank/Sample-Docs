import React from "react";
import "./thankYouModal.scss";
import { ReactComponent as SuccessIcon } from '../../../../assets/icon/Success v1.svg'

interface ThankYouModalProps {
  onClose: () => void;
}

const ThankYouModal: React.FC<ThankYouModalProps> = ({ onClose }) => (
  <div className="modal-overlay">
    <div className="thank-you-modal">
      <div className="title-close-btn">
        <div className="title-text">Share Your Feedback</div>
        <button className="close-button" onClick={onClose}>
          ×
        </button>
      </div>
      <div className="modal-content">
        <SuccessIcon />
      </div>
      <span className="thank-you-head">Thank you for your feedback! </span>
      <p>Your rating has been recorded. We value your opinion and strive to provide the best experience possible.</p>
      <button className="close-done-button" onClick={onClose}>
        Done
      </button>
    </div>
  </div>
);

export default ThankYouModal;