import React, { useState } from 'react';
import './feedbackModal.scss';
import RatingForModal from '../rating-for-modal/ratingForModal';
import ThankYouModal from './ThankYouModal';
import { ReactComponent as IButtonIcon } from '../../../../assets/icon/Ibutton.svg';
import { ReactComponent as ThumbsUpIcon } from '../../../../assets/icon/thumb-up.svg';
import { ReactComponent as ThumbsDownIcon } from '../../../../assets/icon/thumb-down.svg';
import { ReactComponent as ThumbsUpWhite } from '../../../../assets/icon/thumb-up copy.svg';
import { ReactComponent as ThumbsDownWhite } from '../../../../assets/icon/thumb-down-white.svg';
import apiService from '../../../../services/api-service/apiService';
import { ToastContainer, toast } from 'react-toastify';

interface FeedbackModalProps {
  onClose: () => void;
  setSelectedRatings: React.Dispatch<React.SetStateAction<string>>;
  selectedRatings: string;
  feedbackType: "good" | "bad";
  setFeedbackType: React.Dispatch<React.SetStateAction<"good" | "bad">>;
  messages: any[];
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({ onClose, setSelectedRatings, selectedRatings, feedbackType, setFeedbackType, messages }) => {
  const [comment, setComment] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setComment(e.target.value);
  };

  const handleSubmit = async () => {
    try {
      const latestAnswerMessage = messages
        .filter((msg) => msg.type === "answer")
        .slice(-1)[0];

      const latestQuestionMessage = messages
        .filter((msg) => msg.type === "question")
        .slice(-1)[0];

      const payload = {
        SessionId: latestAnswerMessage?.id || 'N/A',
        MessageId: latestAnswerMessage?.messageId || 'N/A',
        Question: latestQuestionMessage?.value || 'N/A',
        Answer: latestAnswerMessage?.value || 'N/A',
        Textual_Feedback: comment,
        Numerical_Feedback: feedbackType === "good" ? 0 : 1,
        reason: selectedRatings,
      };

      console.log("Feedback submitted successfully:", payload);
      const response = await apiService.postFeedback(payload);
      setIsSubmitted(true);

      if (response && response.status === 200) {
        toast.success("Feedback submitted successfully!");
        setIsSubmitted(true);
      } else {
        onClose();
        throw new Error("Unexpected response from server");
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
      toast.error("Failed to submit feedback. Please try again.");
    }
  }

  const handleThankYouClose = () => {
    setIsSubmitted(false);
    onClose();
  };

  if (isSubmitted) {
    return <ThankYouModal onClose={handleThankYouClose} />;
  }

  return (
    <div className="modal-overlay">
      <div className="feedback-modal">
        <div className="title-close-btn">
          <div className="title-text">Share Your Feedback</div>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        <div className="feedback-type">
          <button
            className={`feedback-type-button ${feedbackType === "good" ? "active" : ""}`}
            onClick={() => setFeedbackType("good")}
          >
            {feedbackType === 'good' ? <ThumbsUpWhite /> : <ThumbsUpIcon />} Good response
          </button>
          <button
            className={`feedback-type-button ${feedbackType === "bad" ? "active" : ""}`}
            onClick={() => setFeedbackType("bad")}
          >
            {feedbackType === 'bad' ? <ThumbsDownWhite /> : <ThumbsDownIcon />} Bad response
          </button>
        </div>

        <div className="question">Why did you choose this rating?</div>
        <RatingForModal
          feedbackType={feedbackType}
          setSelectedRatings={setSelectedRatings}
          selectedRatings={selectedRatings}
        />
        <div className="comments-section">
          <label>Any Suggestions or Comments?</label>
          <textarea
            placeholder="Enter your comments here"
            value={comment}
            onChange={handleCommentChange}
            maxLength={3000}
          />
          <div className="char-count"><IButtonIcon /> {`${comment.length}/3000`}</div>
        </div>

        <div className="actions">
          <button className="cancel-button" onClick={onClose}>Cancel</button>
          <button
            className="submit-button"
            onClick={handleSubmit}
            disabled={comment.trim().length === 0} // Disable if no comment
          >
            Submit
          </button>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default FeedbackModal;