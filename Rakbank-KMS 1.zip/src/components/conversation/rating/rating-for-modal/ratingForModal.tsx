import React from "react";
import "./ratingForModal.scss";

interface RatingData {
  tooltipText: string;
}

interface RatingForModalProps {
  feedbackType: "good" | "bad"; // Determines whether to render good or bad cards
  setSelectedRatings: React.Dispatch<React.SetStateAction<string>>; // Accepts a state setter function
  selectedRatings: string; // Current selected ratings
}

const RatingForModal: React.FC<RatingForModalProps> = ({ feedbackType, setSelectedRatings, selectedRatings }) => {
  const ratingGoodData: RatingData[] = [
    { tooltipText: "Correct" },
    { tooltipText: "Easy to Understand" },
    { tooltipText: "Complete" },
  ];

  const ratingBadData: RatingData[] = [
    { tooltipText: "Offensive / Unsafe" },
    { tooltipText: "Not Factually Correct" },
    { tooltipText: "Wrong Language" },
  ];

  // Choose data based on feedback type
  const ratingData = feedbackType === "good" ? ratingGoodData : ratingBadData;

  // Handle card click
  const handleCardClick = (tooltipText: string) => {
    setSelectedRatings((prev: string) => {
      const currentArray = prev ? prev.split(",") : [];
      return currentArray.includes(tooltipText)
        ? currentArray.filter((item) => item !== tooltipText).join(",")  // Remove if already selected
        : [...currentArray, tooltipText].join(",");  // Add if not selected
    });
  };
  

  return (
    <div className="rating-for-modal-container">
      <div className="rating-cards">
        {ratingData.map((rating, index) => (
          <button
            key={index}
            className={`rating-card ${
              selectedRatings.includes(rating.tooltipText) ? "selected" : ""
            }`}
            onClick={() => handleCardClick(rating.tooltipText)}
          >
            {rating.tooltipText}
          </button>
        ))}
      </div>
    </div>
  );
};

export default RatingForModal;