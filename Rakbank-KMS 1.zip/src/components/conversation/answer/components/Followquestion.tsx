import "./followquestion.scss";
import React, { useState } from "react";
// import { data } from "../../../../pages/home/data/staticData";
// import { updateMessages } from "../../../../redux/actions/action";
// import apiService from "../../../../services/api-service/apiService";
// import { ReactComponent as Bulb } from "../../../../assets/icon/lightbulb.svg";
import { ReactComponent as Thumbsup } from "../../../../assets/icon/thumb-up.svg";
import { ReactComponent as Thumbsdowm } from "../../../../assets/icon/thumb-down.svg";
import { ReactComponent as Copy } from "../../../../assets/icon/copy.svg";
import { ReactComponent as Pinicon } from "../../../../assets/icon/pinicon.svg";
import { ReactComponent as Toprighticon } from "../../../../assets/icon/toprightcornericon.svg";
import { sourcesLinkData } from "../../../../data/staticSourcesLinkData";
import Sourse from "./Sourse";
// import useSuggestionBoxClickHandler from "../../../../utils/custom-hooks/useSuggestionBoxClickHandler";
// import { useDispatch } from "react-redux";
// import { v4 as uuidv4 } from "uuid";

interface ContextEntry {
  search_type?: string;
  model?: string;
  chunk_content?: string;
  score?: number;
  filename?: string;
  file_location?: string;
  chunk_heading?: string;
}

interface BaseMessage {
  id: number;
  value: string;
}

interface AnswerMessage extends BaseMessage {
  type: 'answer';
  context: ContextEntry[]; // context is required for 'answer'
  messageId: string;
}

interface QuestionMessage extends BaseMessage {
  type: 'question';
  // context is not allowed for 'question'
}

type Message = AnswerMessage | QuestionMessage;

// Define the props interface for the Followquestion component
interface FollowquestionProps {
  text: string;
  context?: ContextEntry[];
  openModal: (type: "good" | "bad") => void;
  selectedRatings: string;
  setIsLoading: (loading: boolean) => void;
  messageID: string;
  messages: Message[]; // messages prop is required for Followquestion component to work correctly
}

// interface AnswerMessageItem {
//   id: string;
//   messageId: string;
//   value: string;
//   type: string;
//   isLoading: boolean;
//   context: any[];
// }

// interface MessageItem {
//   id: number;
//   value: string;
//   type: string;
//   messageId: string;
// }

const Followquestion: React.FC<FollowquestionProps> = ({ text, context, openModal, selectedRatings, setIsLoading, messageID, messages }) => {
  // const dispatch = useDispatch();
  // const suggestionBoxClickHandler = useSuggestionBoxClickHandler();

  const [tooltip, setTooltip] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [isTableVisible, setIsTableVisible] = useState<boolean>(false);
  // const [conversationId, setConversationId] = useState<string>(uuidv4());

  // const latestAnswerMessage = messages
  //   .filter((message): message is AnswerMessage => message.type === 'answer') // Type guard
  //   .reduce((latest, current) => (latest.messageId > current.messageId ? latest : current), messages[0] as AnswerMessage);

  function filterTopFilenames() {
    // Define the input array type
    interface ContextItem {
      filename?: string;
    }

    const contex: ContextItem[] = context || [];

    const filenameCounts: Record<string, number> = {};

    contex.forEach((item) => {
      const filename = item?.filename;
      if (filename) { // Ensure filename is not undefined
        filenameCounts[filename] = (filenameCounts[filename] || 0) + 1;
      }
    });

    const sortedFilenames = Object.keys(filenameCounts).sort(
      (a, b) => filenameCounts[b] - filenameCounts[a]
    );

    // Use a Set to ensure only unique filenames are added
    const uniqueFilteredData: ContextItem[] = [];
    const seenFilenames = new Set<string>();

    sortedFilenames.forEach((filename) => {
      if (!seenFilenames.has(filename)) {
        const item = contex.find((contextItem) => contextItem.filename === filename);
        if (item) {
          uniqueFilteredData.push(item);
          seenFilenames.add(filename);
        }
      }
    });

    return uniqueFilteredData.slice(0, 5);
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(
      () => {
        setTooltip("Copied!"); // Show tooltip
        setIsCopied(true); // Change state to "clicked"
        setTimeout(() => setTooltip(null), 2000); // Hide tooltip after 2 seconds
      },
      (err) => {
        console.error("Failed to copy: ", err);
      }
    );
  };

  // const fetchAnswer = async (question: string, type: string) => {
  //   setIsLoading(true);
  //   console.log('type', type);
  //   try {
  //     const payload = {
  //       departmant: ["Sales"],
  //       chatRequest: {
  //         Query: question,
  //         ChatHistory: [
  //           {
  //             user: "",
  //             assistant: "",
  //             conversationId: conversationId,
  //             messageId: Date.now().toString(),
  //           },
  //         ],
  //       },
  //     };

  //     const response = await apiService.sendChat(payload);
  //     console.log("response", response);
  //     const newMessage: AnswerMessageItem = {
  //       id: conversationId,
  //       value: response.data.answer.content,
  //       messageId: Date.now().toString(),
  //       type: "answer",
  //       isLoading: true,
  //       context: response.data.context || []
  //     };
  //     dispatch(updateMessages(newMessage));
  //   } catch (error) {
  //     console.log(error);
  //     const newMessage: AnswerMessageItem = {
  //       id: conversationId,
  //       value: "Unable to get response!",
  //       messageId: Date.now().toString(),
  //       type: "answer",
  //       isLoading: true,
  //       context: []
  //     };
  //     setTimeout(() => {
  //       dispatch(updateMessages(newMessage));
  //     }, 2000);
  //   } finally {
  //     setTimeout(() => {
  //       setIsLoading(false);
  //     }, 2000);
  //   }
  // };


  const showTooltip = (message: string) => setTooltip(message);
  const hideTooltip = () => setTooltip(null);

  return (
    <div className="maincontainer">
      {/* {latestAnswerMessage.messageId === messageID && (
        <div className="upperheading">
          <div className="bulb">
            <Bulb />
          </div>
          <div className="heading">
            <span className="heading-title">Follow-up questions</span>
          </div>
        </div>
      )}

      <div className="followquestions-page-suggestion-container">
        {latestAnswerMessage.messageId === messageID && data.followQuestionData.map(
          (
            box: { image: string; title: string; description: string },
            index: number
          ) => (
            <button className="followquestions-suggestion-box" key={index} onClick={() => suggestionBoxClickHandler(box.description, false, fetchAnswer)}>
              <div className="top">
                <img
                  style={{ height: "24px" }}
                  src={box.image}
                  alt={box.title}
                />
              </div>
              <div className="middle">{box.title}</div>
              <div className="bottom">{box.description}</div>
            </button>
          )
        )}
      </div> */}
      {/* {latestAnswerMessage.messageId === messageID && <hr className="hr-border-line" />} */}
      <div className="footer">
        {text !== 'Unable to get response!' && (
          <div className="leftside">
            <Sourse setIsTableVisible={setIsTableVisible} dataLength={filterTopFilenames().length} isTableVisible={isTableVisible} />
          </div>
        )}
        <div className="rightside">
          {text !== 'Unable to get response!' && (
            <div className="thumbs">
              <button
                className="thumbsup"
                onClick={() => openModal('good')}
                onMouseEnter={() => showTooltip('Good Response')}
                onMouseLeave={hideTooltip}
                disabled={selectedRatings.length !== 0}
              >
                <Thumbsup />
              </button>
              <button
                className="thumbsdown"
                onClick={() => openModal('bad')}
                onMouseEnter={() => showTooltip("Bad Response")}
                onMouseLeave={hideTooltip}
                disabled={selectedRatings.length !== 0}
              >
                <Thumbsdowm />
              </button>
            </div>
          )}
          <button
            className="copy"
            onClick={handleCopy}
            onMouseEnter={() => showTooltip(isCopied ? "Clicked" : "Copy to clipboard")}
            onMouseLeave={hideTooltip}
          >
            <Copy />
          </button>
          {tooltip && <div className="tooltip">{tooltip}</div>}
        </div>
      </div>
      {isTableVisible && (
        <div className="table-container">
          {filterTopFilenames().map((data) => {
            const linkData = sourcesLinkData[data.filename as keyof typeof sourcesLinkData];
            return (
              <div className="child-table-container" key={data.filename}>
                <div className="left-content">
                  <Pinicon />
                  <a
                    href={linkData?.redirectLink || '/nolinkfound'}
                    className="item-text"
                    target="_blank"
                  >
                    {data.filename}
                  </a> </div>
                <span className="right-content"><Toprighticon /></span>
              </div>
            )
          })}
        </div>
      )}

    </div>
  );
};

export default Followquestion;
