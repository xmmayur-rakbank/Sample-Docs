import { Dispatch, SetStateAction } from "react";
import "./sourse.scss";
import { ReactComponent as Expand } from "../../../../assets/icon/expand_more.svg";
import {ReactComponent as Expandless} from "../../../../assets/icon/expand_less.svg"

interface SourseProps {
    setIsTableVisible: Dispatch<SetStateAction<boolean>>; // Type for setIsTableVisible
    dataLength: number; 
    isTableVisible: boolean;
  }

  const Sourse: React.FC<SourseProps> = ({ setIsTableVisible, dataLength, isTableVisible }) => {

  const toggleTable = (): void => {
    setIsTableVisible((prev: boolean) => !prev); // Toggle table visibility
  };

  return (
    <div>
      <div className="leftsid" onClick={toggleTable} style={{ cursor: "pointer" }}>
        <div className="sourses">Sources • {dataLength}</div>
        <div className="expand">
        {isTableVisible ? <Expandless /> : <Expand />} 
        </div>
      </div>
    </div>
  );
}

export default Sourse;
