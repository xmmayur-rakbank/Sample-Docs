import "./answer.scss";
import React, { useState } from "react";
import { ReactComponent as AnswerIcon } from "../../../assets/icon/answer_icon.svg";
import { useSelector } from "react-redux";
import detailedLogo from '../../../assets/icon/detailed-answer-logo.svg'
import summarizedLogo from '../../../assets/icon/summarized-answer-logo.svg'
import ReactMarkdown from "react-markdown";
import FeedbackModal from "../rating/modal/FeedbackModal";
import Followquestion from "./components/Followquestion";

interface ContextEntry {
  search_type?: string;
  model?: string;
  chunk_content?: string;
  score?: number;
  filename?: string;
  file_location?: string;
  chunk_heading?: string;
}

interface AnswerProps {
  msg: {
    id: number;
    messageId: string;
    type: "answer" | "question";
    value: string; // Changed from content to value 
    context?: ContextEntry[];
  };
  index: number;
  totalMessagesLength: number
  setIsLoading: (loading: boolean) => void;
}

interface BaseMessage {
  id: number;
  value: string;
}

interface AnswerMessage extends BaseMessage {
  type: 'answer';
  context: ContextEntry[]; // context is required for 'answer'
  messageId: string;
}

interface QuestionMessage extends BaseMessage {
  type: 'question';
  // context is not allowed for 'question'
}

type Message = AnswerMessage | QuestionMessage;

interface RootState {
  stateReducers: {
    messages: Message[];
  };
}
const Answer: React.FC<AnswerProps> = ({ msg, index, totalMessagesLength, setIsLoading }) => {
  const getFomattedImageMessage = () => {
    let formattedMessage = msg.value;
    formattedMessage = formattedMessage?.replace(/<Summarized_logo><\/Summarized_logo>/g, `![summarized Logo](${summarizedLogo})`);
    formattedMessage = formattedMessage?.replace(/<Detailed_logo><\/Detailed_logo>/g, `![detailed Logo](${detailedLogo})`);
    return formattedMessage
  }
  const [selectedRatings, setSelectedRatings] = useState<string>(''); // Stores selected feedback values
  const [isRatingModalOpen, setIsRatingModalOpen] = useState<boolean>(false);
  const [feedbackType, setFeedbackType] = useState<"good" | "bad">("good"); // Determines which feedback type is active
  const messages = useSelector((state: RootState) => state.stateReducers.messages);

  const openModal = (type: "good" | "bad") => {
    setFeedbackType(type);
    setIsRatingModalOpen(true);
  };
  const closeModal = () => setIsRatingModalOpen(false);

  return (
    <div key={msg.id} className="searchResultChild">
      <div className="searchResultChildContainer">
        <div className="sourcesCards">
          <AnswerIcon style={{ width: "2.5rem" }} />
          <div className="answerContainer">
            <ReactMarkdown>{getFomattedImageMessage()}</ReactMarkdown>
          </div>
        </div>
        <hr className="hr-border-line" />
        <Followquestion text={msg.value} context={msg.context} openModal={openModal} selectedRatings={selectedRatings} setIsLoading={setIsLoading} messageID={msg.messageId} messages={messages} />
        {isRatingModalOpen && (
          <FeedbackModal
            onClose={closeModal}
            setSelectedRatings={setSelectedRatings}
            selectedRatings={selectedRatings}
            feedbackType={feedbackType}
            setFeedbackType={setFeedbackType}
            messages={messages}
          />
        )}
      </div>
    </div>
  );
};

export default Answer;





