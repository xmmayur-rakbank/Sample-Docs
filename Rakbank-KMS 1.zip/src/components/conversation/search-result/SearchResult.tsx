import React from 'react';
import { relatedSearchData } from '../../../pages/conversation/data/data';
import { ReactComponent as ThreeDotsIcon } from '../assets/icon/three-dots.svg';
import { ReactComponent as CalendarIcon } from '../assets/icon/calendar.svg';
import { ReactComponent as FileIcon } from '../assets/icon/file.svg';
import { ReactComponent as AuthorCircleIcon } from '../assets/icon/author-circle.svg';

import './searchResult.scss';

// Define types for the relatedSearchData items
interface RelatedSearchItem {
    id: number;
    iconText: string;
    title: string;
    meta: string;
    procedure: string;
    description: string;
}

const SearchResult: React.FC = () => {
    return (
        <div className="search-result-container">
            <h1 className="header-text">Search results</h1>
            <div className="filtersHeader">
                <div className="filterHeaderWrapLeft">
                    <div className="divFilter">
                        <CalendarIcon />
                        <select className="selectUpdate" aria-label="Filter by update date">
                            <option key="updated-on">Updated on</option>
                            <option key="last-24-hours">Last 24 hours</option>
                            <option key="last-week">Last week</option>
                            <option key="last-month">Last month</option>
                        </select>
                    </div>
                    <div className="divFilter">
                        <AuthorCircleIcon />
                        <select className="selectUpdate" aria-label="Filter by author">
                            <option key="author">Author</option>
                            <option key="author-1">Author 1</option>
                            <option key="author-2">Author 2</option>
                            <option key="author-3">Author 3</option>
                        </select>
                    </div>
                    <div className="divFilter">
                        <FileIcon />
                        <select className="selectUpdate" aria-label="Filter by file type">
                            <option key="type">Type</option>
                            <option key="pdf">PDF</option>
                            <option key="docx">DOCX</option>
                            <option key="html">HTML</option>
                        </select>
                    </div>
                </div>
                <div className="filterHeaderWrapLeft">
                    <div className="divFilter">
                        <select className="selectUpdate" aria-label="Sort by relevance">
                            <option key="relevance">Relevance</option>
                            <option key="most-relevant">Most relevant</option>
                            <option key="least-relevant">Least relevant</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="filtersBody">
                <ul className="filtersBodyContent">
                    {relatedSearchData.map((item: RelatedSearchItem) => (
                        <li key={item.id} className="filtersBodyWrap">
                            <div className="filtersHeaderContainer">
                                <div className="filtersBodyTitle">
                                    <div className="heading-title-icon">
                                        <span className="icon">{item.iconText}</span>
                                        <span style={{ fontWeight: "bold" }}>{item.title}</span>
                                    </div>
                                    <div className="filtersBodyTimestamp">
                                        {item.meta} <span id="timestampProcedure">{item.procedure}</span>
                                    </div>
                                </div>
                                <span id="filterThreedots" aria-label="Options">
                                    <ThreeDotsIcon />
                                </span>
                            </div>
                            <div className="filtersBodyDetails">
                                {item.description}
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default SearchResult;
