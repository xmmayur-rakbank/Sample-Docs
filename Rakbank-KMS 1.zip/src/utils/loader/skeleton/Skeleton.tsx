import React from 'react';
import './skeleton.scss';

const SkeletonLoader: React.FC = () => {
  return (
    <div className="skeleton-loader-container">
      <div className="skeleton-loader small"></div>
      <div className="skeleton-loader large"></div>
    </div>
  );
};

export default SkeletonLoader;
