import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { updateMessages } from "../../redux/actions/action";

interface MessageItem {
  id: number;
  value: string;
  type: string;
  isLoading: boolean;
}

type FetchAnswerFunction = (question: string, type: string) => void;

const useSuggestionBoxClickHandler = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const suggestionBoxClickHandler = (question: string, shouldNavigate: boolean, fetchAnswer?: FetchAnswerFunction) => {
    if (question) {
      const newMessage: MessageItem = {
        id: Date.now(), // Unique ID based on timestamp
        value: question,
        type: "question",
        isLoading: true,
      };
      dispatch(updateMessages(newMessage));

      // Call fetchAnswer only if it's provided
      if (fetchAnswer) {
        fetchAnswer(question, 'suggestion box click handler');
      }

      // Navigate only if shouldNavigate is true
      if (shouldNavigate) {
        navigate("/conversation");
      }
    }
  };

  return suggestionBoxClickHandler;
};

export default useSuggestionBoxClickHandler;
