import React, { FC } from "react";
import "./pageNotFound.scss";
import LogoIcon from '../../layout/assets/icons/Logo.png';
import { useNavigate } from "react-router-dom";
const PageNotFound: FC = () => {
    const navigate = useNavigate();
    return (
        <div className="not-found-page">
            <div className="container">
                <div className="company-name">
                    <img src={LogoIcon} alt="" />
                    <span className="company-title">RakBank</span>
                </div>
                <span className="error-title">404</span>
                <span className="oops-text">OOPS! PAGE NOT FOUND</span>
                    <span className="error-code"> Look like you're lost! The page you are looking for not avaible !</span>
                <span className="hint-text">Please click on button to go Home Page !</span>
                <div className="email-input">
                    <button type="button" onClick={() => navigate('/')}>Go To Home</button>
                </div>
            </div>
        </div>
    );
};

export default PageNotFound;
