import "./navbar.scss";
import { useState, useEffect, useRef } from "react";
import { ReactComponent as RakbankLogo } from './assets/rakbank-logo.svg';
import { ReactComponent as ArrowDownwardIcon } from '../../assets/icon/arrow-downward.svg';
import { ReactComponent as ArrowRightIcon } from '../../assets/icon/arrow-right.svg';
import { ReactComponent as CrossIcon } from '../../assets/icon/cross.svg'; // Updated to correct icon path
import { ReactComponent as MenubarIcon } from '../../assets/icon/menubar.svg';
import { useNavigate } from "react-router-dom";

const Navbar: React.FC = () => {
    const [menuOpen, setMenuOpen] = useState<boolean>(false);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const navigate = useNavigate();
    const dropdownRef = useRef<HTMLDivElement | null>(null); // Type the ref

    const toggleMenuOption = () => {
        setIsOpen(prev => !prev);
    };

    const toggleHamburger = () => {
        setMenuOpen(prev => !prev);
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div className="navbar">
            <div className="left">
                <div className="hamburger" onClick={toggleHamburger}>
                    <MenubarIcon />
                </div>
                <span className="rakbank-logo" onClick={() => navigate('/')}>
                    <RakbankLogo />
                </span>
            </div>
            <div className="right">
                <div className="rightNav">
                    <div className="dashboard navFontStyling">Dashboard</div>
                    <div className="analytics navFontStyling">Analytics</div>
                    <div className="repository navFontStyling">Repository</div>
                </div>
                <div className="menu menuStyling" onClick={toggleMenuOption} ref={dropdownRef}>
                    Menu <ArrowDownwardIcon className="svg-icon" />
                    {isOpen && (
                        <div className="dropdown">
                            <div className="dropdownItem">Feedback & Improvement <span><ArrowRightIcon /></span></div>
                            <div className="dropdownItem">User Management <span><ArrowRightIcon /></span></div>
                            <div className="dropdownItem">Help & Support <span><ArrowRightIcon /></span></div>
                        </div>
                    )}
                </div>
                <div className="avatar">
                    <div className="custom-avatar">AG</div>
                </div>
            </div>
            {menuOpen && (
                <div className="mobileMenu">
                    <div className="crossMenu" onClick={toggleHamburger}><CrossIcon /></div>
                    <div className="menuItem">Dashboard</div>
                    <div className="menuItem">Analytics</div>
                    <div className="menuItem">Repository</div>
                </div>
            )}
        </div>
    );
};

export default Navbar;