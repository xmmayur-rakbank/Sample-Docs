import "./layout.scss";
import { useState } from "react";
import Sidebar from "./sidebar/Sidebar";

interface LayoutProps {
  Cmp: React.FC; // Define the type for the Cmp prop as a functional component
}

const Layout: React.FC<LayoutProps> = ({ Cmp }) => {
  const [isSidebarActive, setIsSidebarActive] = useState(true)
  return (
    <div className="rakbank-app-layout">
      <Sidebar isSidebarActive={isSidebarActive} setIsSidebarActive={setIsSidebarActive} />
      <Cmp />
    </div>
  );
}

export default Layout;