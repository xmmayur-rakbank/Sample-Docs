
import './sidebar.scss'; // Custom SCSS for styling
import LogoIcon from '../assets/icons/Logo.png';
import { ReactComponent as SettingIcon } from '../assets/icons/sidebar-settings-link.svg';
import { ReactComponent as ProfileIcon } from '../assets/icons/sidebar-profile-link.svg';
import { ReactComponent as ToggleSidebarIcon } from "../../assets/icon/right_icon.svg";
import { useNavigate } from 'react-router-dom';
import { startNewConversation } from '../../redux/actions/action';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';

interface SidebarProps {
    isSidebarActive: boolean;
    setIsSidebarActive: React.Dispatch<React.SetStateAction<boolean>>;
}

const Sidebar: React.FC<SidebarProps> = ({ isSidebarActive, setIsSidebarActive }) => {
    let navigate = useNavigate();
    let dispatch = useDispatch()

    const startNewConversationHandeler = () => {
        console.log("dasaa")
        dispatch(startNewConversation([]));
        navigate('/')
    }

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 800) {
                setIsSidebarActive(false);
            } else {
                setIsSidebarActive(true);
            }
        }

        handleResize();
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
        }
    }, [])

    return (
        <div className={`rak_bank_sidebar ${isSidebarActive ? 'active' : ''}`}>
            <div className={`sidebar-header ${!isSidebarActive ? 'sideIsActive' : ''}`}>
                <div className='logo_title_section'>
                    <button className='logo_section'>
                        <img src={LogoIcon} alt="" />
                    </button>
                    {isSidebarActive && <p className='title_section'>RAKBANK</p>}
                </div>
                <button onClick={() => setIsSidebarActive((prev) => !prev)} className='close_icon'>
                    <ToggleSidebarIcon />
                </button>
            </div>
            <button className="new-conversation-button" onClick={startNewConversationHandeler}>
                <span>+ </span>
                {isSidebarActive && <span>New Conversation</span>}
            </button>
            <hr />
            <footer className="sidebar-footer">
                <button className="footer-button">
                    <SettingIcon />
                    {isSidebarActive && <span>Settings</span>}
                </button>
                <button className="footer-button">
                    <ProfileIcon />
                    {isSidebarActive && <span>My Profile</span>}
                </button>
            </footer>
        </div>
    );
};

export default Sidebar;
